<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: loginRegister.php");
    exit();
}

if (!isset($_GET["id"])) {
    header("Location: dashboard.php");
    exit();
}

$book_id = $_GET["id"];

try {
    require_once "includes/dbh.inc.php";

    // Get book details
    $query = "SELECT * FROM books WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$book_id]);
    $book = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if book exists and if user is the creator
    if (!$book || $book['user_id'] != $_SESSION['user_id']) {
        header("Location: dashboard.php");
        exit();
    }

    $pdo = null;
} catch (PDOException $e) {
    die("Query failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Edit Book</h1>
            <div>
                <a href="dashboard.php" class="btn btn-outline-primary">Go Back</a>
                <a href="logout.php" class="btn btn-outline-danger">Log Out</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <?php if (isset($_SESSION["edit_error"])): ?>
                    <div class="alert alert-danger">
                        <?php 
                            echo $_SESSION["edit_error"];
                            unset($_SESSION["edit_error"]);
                        ?>
                    </div>
                <?php endif; ?>
                <form action="includes/showEdit.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $book['id']; ?>">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($book['title']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="5"><?php echo htmlspecialchars($book['description']); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-warning">Update</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
