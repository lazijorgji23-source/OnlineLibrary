<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../loginRegister.php");
    exit();
}

if (isset($_GET["id"]) && isset($_GET["action"])) {
    $book_id = $_GET["id"];
    $user_id = $_SESSION["user_id"];
    $action = $_GET["action"];
    $source = isset($_GET["source"]) ? $_GET["source"] : "dashboard";

    try {
        require_once "dbh.inc.php";

        if ($action == "add") {
            $query = "INSERT INTO favorites (user_id, book_id) VALUES (?, ?);";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$user_id, $book_id]);
        } elseif ($action == "remove") {
            $query = "DELETE FROM favorites WHERE user_id = ? AND book_id = ?;";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$user_id, $book_id]);
        }

        if ($source == "details") {
            header("Location: ../oneShow.php?id=" . $book_id);
        } else {
            header("Location: ../dashboard.php");
        }
        exit();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../dashboard.php");
    exit();
}
