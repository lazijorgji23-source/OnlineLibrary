<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../loginRegister.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = htmlspecialchars($_POST["title"]);
    $description = htmlspecialchars($_POST["description"]);
    $user_id = $_SESSION["user_id"];

    // Validimet
    if (empty($title)) {
        $_SESSION["book_error"] = "Title is required.";
        header("Location: ../dashboard.php");
        exit();
    }

    if (strlen($description) < 5) {
        $_SESSION["book_error"] = "Description must be at least 5 characters.";
        header("Location: ../dashboard.php");
        exit();
    }

    try {
        require_once "dbh.inc.php";

        // Insert book
        $query = "INSERT INTO books (title, description, user_id) VALUES (?, ?, ?);";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$title, $description, $user_id]);
        $book_id = $pdo->lastInsertId();

        // Ninja Bonus: Automatically favorite the book for the creator
        $favQuery = "INSERT INTO favorites (user_id, book_id) VALUES (?, ?);";
        $favStmt = $pdo->prepare($favQuery);
        $favStmt->execute([$user_id, $book_id]);

        header("Location: ../dashboard.php");
        exit();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../dashboard.php");
    exit();
}
