<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    if (empty($email) || empty($password)) {
        $_SESSION["error"] = "All fields are required.";
        header("Location: ../loginRegister.php");
        exit();
    }

    try {
        require_once "dbh.inc.php";

        // Get user by email
        $query = "SELECT * FROM users WHERE email = ?;";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Verify the password
            if ($password == $user["password"]) {
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["firstName"] = $user["firstName"];

                $pdo = null;
                $stmt = null;
                
                // Redirect to dashboard
                header("Location: ../dashboard.php");
                exit();
            } else {
                $_SESSION["error"] = "Invalid email or password.";
                header("Location: ../loginRegister.php");
                exit();
            }
        } else {
            $_SESSION["error"] = "Invalid email or password.";
            header("Location: ../loginRegister.php");
            exit();
        }

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../loginRegister.php");
    exit();
}
