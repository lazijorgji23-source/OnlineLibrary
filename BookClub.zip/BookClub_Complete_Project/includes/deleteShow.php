<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../loginRegister.php");
    exit();
}

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $user_id = $_SESSION["user_id"];

    try {
        require_once "dbh.inc.php";

        // Delete book (only if user is the creator)
        $query = "DELETE FROM books WHERE id = ? AND user_id = ?;";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$id, $user_id]);

        header("Location: ../dashboard.php");
        exit();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../dashboard.php");
    exit();
}
