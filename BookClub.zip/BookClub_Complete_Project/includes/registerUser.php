<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = htmlspecialchars($_POST["firstName"]);
    $lastName = htmlspecialchars($_POST["lastName"]);
    $email = htmlspecialchars($_POST["email"]);
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirmPassword"];

    // Kontrolli i fushave bosh
    if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($confirmPassword)) {
        $_SESSION["error1"] = "All fields are required.";
        header("Location: ../loginRegister.php");
        exit();
    }

    // Validimi i emrit dhe mbiemrit (min 2 karaktere)
    if (strlen($firstName) < 2 || strlen($lastName) < 2) {
        $_SESSION["error1"] = "First name and last name should be at least 2 characters.";
        header("Location: ../loginRegister.php");
        exit();
    }

    // Kontrolli i formatit të email-it
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION["error1"] = "Email address should be valid.";
        header("Location: ../loginRegister.php");
        exit();
    }

    // Validimi i fjalëkalimit (min 8 karaktere)
    if (strlen($password) < 8) {
        $_SESSION["error1"] = "Password should be at least 8 characters.";
        header("Location: ../loginRegister.php");
        exit();
    }

    // Kontrolli i përputhjes së fjalëkalimeve
    if ($password !== $confirmPassword) {
        $_SESSION["error1"] = "Passwords should match.";
        header("Location: ../loginRegister.php");
        exit();
    }

    try {
        require_once "dbh.inc.php";

        // Kontrollo nëse email-i ekziston në databazë
        $emailCheckQuery = "SELECT COUNT(*) FROM users WHERE email = ?";
        $stmt = $pdo->prepare($emailCheckQuery);
        $stmt->execute([$email]);
        $emailExists = $stmt->fetchColumn();

        if ($emailExists > 0) {
            $_SESSION["error1"] = "Email already in use.";
            header("Location: ../loginRegister.php");
            exit();
        }

        // Regjistrimi i përdoruesit të ri
        $query = "INSERT INTO users (firstName, lastName, email, password) VALUES (?, ?, ?, ?);";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$firstName, $lastName, $email, $password]);

        // Ruajtja e të dhënave në sesion
        $_SESSION["user_id"] = $pdo->lastInsertId();
        $_SESSION["firstName"] = $firstName;

        // Mbyll lidhjet
        $pdo = null;
        $stmt = null;

        // Redirect pas regjistrimit të suksesshëm
        header("Location: ../dashboard.php");
        exit();

    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../loginRegister.php");
    exit();
}
