<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Club</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <h1 class="text-center text-primary mt-4">Book Club</h1>
    <div class="d-flex justify-content-around">
        <div class="w-50">
            <form class="w-50 m-auto mt-4 p-3 h-100" action="includes/registerUser.php" method="post">
                <h2 class="text-center">Register</h2>
                <?php if (isset($_SESSION["error1"])): ?>
                    <div class="alert alert-danger">
                        <?php 
                            echo $_SESSION["error1"];
                            unset($_SESSION["error1"]);
                        ?>
                    </div>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="firstName" class="form-label">First Name:</label>
                    <input type="text" class="form-control" name="firstName" id="firstName">
                </div>
                <div class="mb-3">
                    <label for="lastName" class="form-label">Last Name:</label>
                    <input type="text" class="form-control" name="lastName" id="lastName">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email address:</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="Enter user email">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password:</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>
                <div class="mb-3">
                    <label for="confirmPassword" class="form-label">Confirm PW:</label>
                    <input type="password" class="form-control" name="confirmPassword" id="confirmPassword">
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>
        </div>
        <div class="w-50">
            <form class="w-50 m-auto mt-4 p-3 h-100" action="includes/loginUser.php" method="post">
                <h2 class="text-center">Login</h2>
                <?php if (isset($_SESSION["error"])): ?>
                    <div class="alert alert-danger">
                        <?php 
                            echo $_SESSION["error"];
                            unset($_SESSION["error"]);
                        ?>
                    </div>
                <?php endif; ?>
                <div class="mb-3">
                  <label for="email" class="form-label">Email address:</label>
                  <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Password:</label>
                  <input type="password" class="form-control" id="password" name="password">
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
