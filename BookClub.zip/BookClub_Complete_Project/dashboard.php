<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: loginRegister.php");
    exit();
}

try {
    require_once "includes/dbh.inc.php";
    
    // Get all books with creator info
    $query = "SELECT books.*, users.firstName as creator_name FROM books 
              JOIN users ON books.user_id = users.id 
              ORDER BY books.created_at DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get user's favorites
    $favQuery = "SELECT book_id FROM favorites WHERE user_id = ?";
    $favStmt = $pdo->prepare($favQuery);
    $favStmt->execute([$_SESSION["user_id"]]);
    $userFavorites = $favStmt->fetchAll(PDO::FETCH_COLUMN);

    $pdo = null;
} catch (PDOException $e) {
    die("Query failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Club - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION["firstName"]); ?>!</h1>
            <a href="logout.php" class="btn btn-outline-danger">Log Out</a>
        </div>

        <div class="row">
            <!-- Add a New Book Section -->
            <div class="col-md-4">
                <h3>Add a New Book</h3>
                <?php if (isset($_SESSION["book_error"])): ?>
                    <div class="alert alert-danger">
                        <?php 
                            echo $_SESSION["book_error"];
                            unset($_SESSION["book_error"]);
                        ?>
                    </div>
                <?php endif; ?>
                <form action="includes/showNew.php" method="post">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Add</button>
                </form>
            </div>

            <!-- All Books Section -->
            <div class="col-md-8">
                <h3>All Books</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Added By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td>
                                    <a href="oneShow.php?id=<?php echo $book['id']; ?>">
                                        <?php echo htmlspecialchars($book['title']); ?>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($book['creator_name']); ?></td>
                                <td>
                                    <?php if ($book['user_id'] == $_SESSION['user_id']): ?>
                                        <a href="editShow.php?id=<?php echo $book['id']; ?>">edit</a> |
                                        <a href="includes/deleteShow.php?id=<?php echo $book['id']; ?>" onclick="return confirm('Are you sure?')">delete</a>
                                    <?php else: ?>
                                        <?php if (in_array($book['id'], $userFavorites)): ?>
                                            <span>this is one of your favorites</span> | 
                                            <a href="includes/favorite.php?action=remove&id=<?php echo $book['id']; ?>">Un-Favorite</a>
                                        <?php else: ?>
                                            <a href="includes/favorite.php?action=add&id=<?php echo $book['id']; ?>">Add to Favorites</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
