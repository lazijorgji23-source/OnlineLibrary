<?php
session_start();
session_unset();
session_destroy();
header("Location: /Book_Club/loginRegister.php");
exit();

