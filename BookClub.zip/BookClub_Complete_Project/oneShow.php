<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: loginRegister.php");
    exit();
}

if (!isset($_GET["id"])) {
    header("Location: dashboard.php");
    exit();
}

$book_id = $_GET["id"];

try {
    require_once "includes/dbh.inc.php";

    // Get book details
    $query = "SELECT books.*, users.firstName as creator_name FROM books 
              JOIN users ON books.user_id = users.id 
              WHERE books.id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$book_id]);
    $book = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$book) {
        header("Location: dashboard.php");
        exit();
    }

    // Get users who like this book
    $favQuery = "SELECT users.firstName, users.lastName, users.id as user_id FROM users 
                 JOIN favorites ON users.id = favorites.user_id 
                 WHERE favorites.book_id = ?";
    $favStmt = $pdo->prepare($favQuery);
    $favStmt->execute([$book_id]);
    $likers = $favStmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if current user likes this book
    $isFavorite = false;
    foreach ($likers as $liker) {
        if ($liker['user_id'] == $_SESSION['user_id']) {
            $isFavorite = true;
            break;
        }
    }

    $pdo = null;
} catch (PDOException $e) {
    die("Query failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION["firstName"]); ?>!</h1>
            <div>
                <a href="dashboard.php" class="btn btn-outline-primary">Go Back</a>
                <a href="logout.php" class="btn btn-outline-danger">Log Out</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <h2><?php echo htmlspecialchars($book['title']); ?></h2>
                <p><strong>Added by:</strong> <?php echo htmlspecialchars($book['creator_name']); ?></p>
                <p><strong>Added on:</strong> <?php echo date('M j, Y @ g:i a', strtotime($book['created_at'])); ?></p>
                <p><strong>Last updated on:</strong> <?php echo date('M j, Y @ g:i a', strtotime($book['updated_at'])); ?></p>
                <p><strong>Description:</strong></p>
                <div class="border p-3 mb-3">
                    <?php echo nl2br(htmlspecialchars($book['description'])); ?>
                </div>

                <?php if ($book['user_id'] == $_SESSION['user_id']): ?>
                    <a href="editShow.php?id=<?php echo $book['id']; ?>" class="btn btn-warning">Update</a>
                    <a href="includes/deleteShow.php?id=<?php echo $book['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <h3>Users Who Like This Book:</h3>
                <ul>
                    <?php foreach ($likers as $liker): ?>
                        <li>
                            <?php echo htmlspecialchars($liker['firstName'] . " " . $liker['lastName']); ?>
                            <?php if ($liker['user_id'] == $_SESSION['user_id']): ?>
                                <a href="includes/favorite.php?action=remove&id=<?php echo $book['id']; ?>&source=details">Un-Favorite</a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php if (!$isFavorite && $book['user_id'] != $_SESSION['user_id']): ?>
                    <a href="includes/favorite.php?action=add&id=<?php echo $book['id']; ?>&source=details">Add to Favorites</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
